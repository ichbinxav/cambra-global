export { default } from './_deps/ded7e66f150c-entry.module.ts';
