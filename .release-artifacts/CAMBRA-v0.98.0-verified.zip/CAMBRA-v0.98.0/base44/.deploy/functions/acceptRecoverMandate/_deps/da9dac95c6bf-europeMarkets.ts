// GENERATED from config/europe-markets.json — DO NOT EDIT.
export const EUROPE_MARKET_REGISTRY={
  "schemaVersion": 1,
  "registryVersion": "p1-europe-2026.08.10",
  "effectiveDate": "2026-08-10",
  "launchScope": {
    "scopeVersion": "founder-market-scope-2026.08.13",
    "effectiveDate": "2026-08-13",
    "decisionStatus": "FOUNDER_DECIDED",
    "canonical_market_count": 33,
    "active_launch_count": 30,
    "protected_market_count": 3,
    "active": [
      "AT",
      "BG",
      "HR",
      "CY",
      "CZ",
      "DK",
      "EE",
      "FI",
      "DE",
      "GR",
      "HU",
      "IE",
      "IT",
      "LV",
      "LT",
      "LU",
      "MT",
      "PL",
      "PT",
      "RO",
      "SK",
      "SI",
      "ES",
      "SE",
      "NO",
      "IS",
      "LI",
      "CH",
      "GB",
      "AD"
    ],
    "protected": [
      "FR",
      "BE",
      "NL"
    ],
    "protectedMode": "RESEARCH_ONLY",
    "outboundMode": "PAUSED_ZERO",
    "regulatedCapabilitiesMode": "SPECIFIC_POLICY_REQUIRED"
  },
  "markets": [
    {
      "iso2": "AT",
      "iso3": "AUT",
      "canonical_name": "Austria",
      "aliases": [
        "Austria"
      ],
      "region": "Europe",
      "subregion": "Western Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Vienna"
      ]
    },
    {
      "iso2": "BE",
      "iso3": "BEL",
      "canonical_name": "Belgium",
      "aliases": [
        "Belgium",
        "Belgique",
        "België"
      ],
      "region": "Europe",
      "subregion": "Western Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Brussels"
      ]
    },
    {
      "iso2": "BG",
      "iso3": "BGR",
      "canonical_name": "Bulgaria",
      "aliases": [
        "Bulgaria"
      ],
      "region": "Europe",
      "subregion": "Eastern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Sofia"
      ]
    },
    {
      "iso2": "HR",
      "iso3": "HRV",
      "canonical_name": "Croatia",
      "aliases": [
        "Croatia"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Zagreb"
      ]
    },
    {
      "iso2": "CY",
      "iso3": "CYP",
      "canonical_name": "Cyprus",
      "aliases": [
        "Cyprus"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Asia/Nicosia"
      ]
    },
    {
      "iso2": "CZ",
      "iso3": "CZE",
      "canonical_name": "Czechia",
      "aliases": [
        "Czechia",
        "Czech Republic"
      ],
      "region": "Europe",
      "subregion": "Eastern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "CZK",
      "timezones": [
        "Europe/Prague"
      ]
    },
    {
      "iso2": "DK",
      "iso3": "DNK",
      "canonical_name": "Denmark",
      "aliases": [
        "Denmark"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "DKK",
      "timezones": [
        "Europe/Copenhagen"
      ]
    },
    {
      "iso2": "EE",
      "iso3": "EST",
      "canonical_name": "Estonia",
      "aliases": [
        "Estonia"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Tallinn"
      ]
    },
    {
      "iso2": "FI",
      "iso3": "FIN",
      "canonical_name": "Finland",
      "aliases": [
        "Finland"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Helsinki"
      ]
    },
    {
      "iso2": "FR",
      "iso3": "FRA",
      "canonical_name": "France",
      "aliases": [
        "France"
      ],
      "region": "Europe",
      "subregion": "Western Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Paris"
      ]
    },
    {
      "iso2": "DE",
      "iso3": "DEU",
      "canonical_name": "Germany",
      "aliases": [
        "Germany",
        "Deutschland"
      ],
      "region": "Europe",
      "subregion": "Western Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Berlin"
      ]
    },
    {
      "iso2": "GR",
      "iso3": "GRC",
      "canonical_name": "Greece",
      "aliases": [
        "Greece"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Athens"
      ]
    },
    {
      "iso2": "HU",
      "iso3": "HUN",
      "canonical_name": "Hungary",
      "aliases": [
        "Hungary"
      ],
      "region": "Europe",
      "subregion": "Eastern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "HUF",
      "timezones": [
        "Europe/Budapest"
      ]
    },
    {
      "iso2": "IE",
      "iso3": "IRL",
      "canonical_name": "Ireland",
      "aliases": [
        "Ireland"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Dublin"
      ]
    },
    {
      "iso2": "IT",
      "iso3": "ITA",
      "canonical_name": "Italy",
      "aliases": [
        "Italy",
        "Italia"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Rome"
      ]
    },
    {
      "iso2": "LV",
      "iso3": "LVA",
      "canonical_name": "Latvia",
      "aliases": [
        "Latvia"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Riga"
      ]
    },
    {
      "iso2": "LT",
      "iso3": "LTU",
      "canonical_name": "Lithuania",
      "aliases": [
        "Lithuania"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Vilnius"
      ]
    },
    {
      "iso2": "LU",
      "iso3": "LUX",
      "canonical_name": "Luxembourg",
      "aliases": [
        "Luxembourg"
      ],
      "region": "Europe",
      "subregion": "Western Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Luxembourg"
      ]
    },
    {
      "iso2": "MT",
      "iso3": "MLT",
      "canonical_name": "Malta",
      "aliases": [
        "Malta"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Malta"
      ]
    },
    {
      "iso2": "NL",
      "iso3": "NLD",
      "canonical_name": "Netherlands",
      "aliases": [
        "Netherlands",
        "The Netherlands",
        "Nederland"
      ],
      "region": "Europe",
      "subregion": "Western Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Amsterdam"
      ]
    },
    {
      "iso2": "PL",
      "iso3": "POL",
      "canonical_name": "Poland",
      "aliases": [
        "Poland"
      ],
      "region": "Europe",
      "subregion": "Eastern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "PLN",
      "timezones": [
        "Europe/Warsaw"
      ]
    },
    {
      "iso2": "PT",
      "iso3": "PRT",
      "canonical_name": "Portugal",
      "aliases": [
        "Portugal"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Lisbon"
      ]
    },
    {
      "iso2": "RO",
      "iso3": "ROU",
      "canonical_name": "Romania",
      "aliases": [
        "Romania"
      ],
      "region": "Europe",
      "subregion": "Eastern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "RON",
      "timezones": [
        "Europe/Bucharest"
      ]
    },
    {
      "iso2": "SK",
      "iso3": "SVK",
      "canonical_name": "Slovakia",
      "aliases": [
        "Slovakia"
      ],
      "region": "Europe",
      "subregion": "Eastern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Bratislava"
      ]
    },
    {
      "iso2": "SI",
      "iso3": "SVN",
      "canonical_name": "Slovenia",
      "aliases": [
        "Slovenia"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Ljubljana"
      ]
    },
    {
      "iso2": "ES",
      "iso3": "ESP",
      "canonical_name": "Spain",
      "aliases": [
        "Spain",
        "España"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": true,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Madrid",
        "Atlantic/Canary"
      ]
    },
    {
      "iso2": "SE",
      "iso3": "SWE",
      "canonical_name": "Sweden",
      "aliases": [
        "Sweden"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": true,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "SEK",
      "timezones": [
        "Europe/Stockholm"
      ]
    },
    {
      "iso2": "NO",
      "iso3": "NOR",
      "canonical_name": "Norway",
      "aliases": [
        "Norway"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": false,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "NOK",
      "timezones": [
        "Europe/Oslo"
      ]
    },
    {
      "iso2": "IS",
      "iso3": "ISL",
      "canonical_name": "Iceland",
      "aliases": [
        "Iceland"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": false,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "ISK",
      "timezones": [
        "Atlantic/Reykjavik"
      ]
    },
    {
      "iso2": "LI",
      "iso3": "LIE",
      "canonical_name": "Liechtenstein",
      "aliases": [
        "Liechtenstein"
      ],
      "region": "Europe",
      "subregion": "Western Europe",
      "eu_member": false,
      "eea_member": true,
      "eurozone_member": false,
      "primary_currency": "CHF",
      "timezones": [
        "Europe/Vaduz"
      ]
    },
    {
      "iso2": "CH",
      "iso3": "CHE",
      "canonical_name": "Switzerland",
      "aliases": [
        "Switzerland",
        "Schweiz",
        "Suisse",
        "Svizzera"
      ],
      "region": "Europe",
      "subregion": "Western Europe",
      "eu_member": false,
      "eea_member": false,
      "eurozone_member": false,
      "primary_currency": "CHF",
      "timezones": [
        "Europe/Zurich"
      ]
    },
    {
      "iso2": "GB",
      "iso3": "GBR",
      "canonical_name": "United Kingdom",
      "aliases": [
        "United Kingdom",
        "UK",
        "Great Britain"
      ],
      "region": "Europe",
      "subregion": "Northern Europe",
      "eu_member": false,
      "eea_member": false,
      "eurozone_member": false,
      "primary_currency": "GBP",
      "timezones": [
        "Europe/London"
      ]
    },
    {
      "iso2": "AD",
      "iso3": "AND",
      "canonical_name": "Andorra",
      "aliases": [
        "Andorra"
      ],
      "region": "Europe",
      "subregion": "Southern Europe",
      "eu_member": false,
      "eea_member": false,
      "eurozone_member": false,
      "primary_currency": "EUR",
      "timezones": [
        "Europe/Andorra"
      ]
    }
  ]
};
export const EUROPE_MARKETS=Object.freeze(EUROPE_MARKET_REGISTRY.markets);
export const EUROPE_MARKET_BY_ISO2=Object.freeze(Object.fromEntries(EUROPE_MARKETS.map(m=>[m.iso2,m])));
export const EUROPE_MARKET_CODES=Object.freeze(EUROPE_MARKETS.map(m=>m.iso2));
export const CANONICAL_MARKET_CODES=EUROPE_MARKET_CODES;
export const EUROPE_CURRENCIES=Object.freeze([...new Set(EUROPE_MARKETS.map(m=>m.primary_currency))]);
export const MARKET_SCOPE_VERSION=EUROPE_MARKET_REGISTRY.launchScope.scopeVersion;
export const MARKET_SCOPE_DECISION_STATUS=EUROPE_MARKET_REGISTRY.launchScope.decisionStatus;
export const ACTIVE_LAUNCH_MARKETS=Object.freeze([...EUROPE_MARKET_REGISTRY.launchScope.active]);
export const PROTECTED_MARKETS=Object.freeze([...EUROPE_MARKET_REGISTRY.launchScope.protected]);
export const RESEARCH_ONLY_MARKETS=PROTECTED_MARKETS;
export const MARKET_SCOPE_COUNTS=Object.freeze({canonical_market_count:EUROPE_MARKET_CODES.length,active_launch_count:ACTIVE_LAUNCH_MARKETS.length,protected_market_count:PROTECTED_MARKETS.length});
export const MARKET_OUTBOUND_MODE=EUROPE_MARKET_REGISTRY.launchScope.outboundMode;
export const MARKET_REGULATED_CAPABILITIES_MODE=EUROPE_MARKET_REGISTRY.launchScope.regulatedCapabilitiesMode;
export const MARKET_SCOPE_BY_ISO2=Object.freeze(Object.fromEntries(EUROPE_MARKET_CODES.map(iso2=>{const launchActive=ACTIVE_LAUNCH_MARKETS.includes(iso2);return[iso2,Object.freeze({iso2,scope_status:launchActive?'ACTIVE_LAUNCH':'PROTECTED_RESEARCH_ONLY',launch_active:launchActive,research_allowed:true,research_only:!launchActive,commercial_scope_eligible:launchActive,outbound_allowed:false,regulated_capabilities_authorized:false})]})));
export function canonicalMarketIso2(value){const iso2=typeof value==='string'?value.trim().toUpperCase():'';return Object.prototype.hasOwnProperty.call(EUROPE_MARKET_BY_ISO2,iso2)?iso2:null}
export function marketScopeForIso2(value){const iso2=canonicalMarketIso2(value);return iso2?MARKET_SCOPE_BY_ISO2[iso2]:null}
export function paymentsRegionForCanonicalMarket(value){const iso2=canonicalMarketIso2(value);if(!iso2)return null;if(iso2==='GB')return'UK';if(iso2==='AD')return'RoW';return'EU'}
