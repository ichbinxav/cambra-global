export { default } from './_deps/8d2643bcb53c-entry.module.ts';
